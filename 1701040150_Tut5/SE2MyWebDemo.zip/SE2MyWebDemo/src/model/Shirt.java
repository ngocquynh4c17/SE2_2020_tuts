package model;

/**
 * This is a model class represents a Shirt entity for the table Shirt in database
 */

public class Shirt {
	protected int ID;
	protected String Style;
	protected String Name;
	protected String Price;
	public Shirt(int iD, String style, String name, String price) {
		super();
		ID = iD;
		Style = style;
		Name = name;
		Price = price;
	}
	public Shirt(String style, String name, String price) {
		super();		
		Style = style;
		Name = name;
		Price = price;
	}
	public Shirt() {
		
	}
	public int getID() {
		return ID;
	}
	public void setID(int iD) {
		this.ID = iD;
	}
	public String getStyle() {
		return Style;
	}
	public void setStyle(String style) {
		this.Style = style;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		this.Name = name;
	}
	public String getPrice() {
		return Price;
	}
	public void setPrice(String price) {
		this.Price = price;
	}
	
	
	
}
