package model;

public class Dress {
	protected int ID;
	protected String Style;
	protected String Name;
	protected String Price;
	public Dress(int iD, String style, String name, String price) {
		super();
		ID = iD;
		Style = style;
		Name = name;
		Price = price;
	}
	
	public Dress() {
		
	}

	public int getID() {
		return ID;
	}

	public void setID(int iD) {
		ID = iD;
	}

	public String getStyle() {
		return Style;
	}

	public void setStyle(String style) {
		Style = style;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getPrice() {
		return Price;
	}

	public void setPrice(String price) {
		Price = price;
	}


}
