package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import model.Customer;
import model.Dress;
import model.Shirt;
import connect.DBConnect;

/**
 * This is a DAO (DATA ACCESS OBJECT) class which provides 
 * CRUD (CREATE - READ - UPDATE - DELETE) database operations 
 * for the table Shirt in the database
 */
public class DAO {

	public DAO() {
	}

	public List<Shirt> selectAllShirts() {
		List<Shirt> Shirts = new ArrayList<>();		
		Connection connection = DBConnect.getConnection();
		try {			
			String SELECT_ALL_ShirtS = "SELECT * FROM Shirt";
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_ShirtS);		
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("id");
				String style = rs.getString("style");
				String name = rs.getString("name");
				String price = rs.getString("price");
				Shirts.add(new Shirt(id, style, name, price));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Shirts;
	}
	
	public List<Dress> selectAllDresses() {
		List<Dress> Dresses = new ArrayList<>();		
		Connection connection = DBConnect.getConnection();
		try {			
			String SELECT_ALL_DresseS = "SELECT * FROM Dress";
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_DresseS);		
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("id");
				String style = rs.getString("style");
				String name = rs.getString("name");
				String price = rs.getString("price");
				Dresses.add(new Dress(id, style, name, price));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Dresses;
	}
	
	public List<Customer> selectAllUseArs() {

		List<Customer> Customers = new ArrayList<>();

		Connection connection = DBConnect.getConnection();
		try {

			String SELECT_ALL_CustomerS = "SELECT * FROM Customer";
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_CustomerS);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();

			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String address = rs.getString("address");
				String mobile = rs.getString("mobile");
				Customers.add(new Customer(id, name, address, mobile));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Customers;
	}
	public Customer selectCustomer(int id) {
		Customer Customer = null;
		Connection connection = DBConnect.getConnection();
		try {
			String selectSQL = "SELECT * FROM Customer WHERE ID = ?";
			PreparedStatement preparedStatement = connection.prepareStatement(selectSQL);
			preparedStatement.setInt(1, id);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {				
				String name = rs.getString("name");
				String address = rs.getString("address");
				String mobile = rs.getString("mobile");
				Customer = new Customer(name, address, mobile);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return Customer;
	}

	// TO-DO: Implement insertCustomer() method to add new record to table Customer  
	public boolean insertCustomer(Customer Customer) throws SQLException {
		Connection connection = DBConnect.getConnection();
		boolean rowInserted = false;
		try {
			String insertSQL = "INSERT INTO Customer (name, address, mobile) VALUES (?,?,?);";
			PreparedStatement ps = connection.prepareStatement(insertSQL);
			ps.setString(1, Customer.getName());
			ps.setString(2, Customer.getAddress());
			ps.setString(3, Customer.getMobile());
			rowInserted = ps.executeUpdate() > 0;
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return rowInserted;
	}

	// TO-DO: Implement updateCustomer() method to update record in table Customer  
	public boolean updateCustomer(Customer Customer) throws SQLException {
		Connection connection = DBConnect.getConnection();
		boolean rowUpdated = false;
		try {
			String insertSQL = "UPDATE Customer SET name = ?, address = ?, mobile = ? WHERE ID = ?;";
			PreparedStatement ps = connection.prepareStatement(insertSQL);
			ps.setString(1, Customer.getName());
			ps.setString(2, Customer.getAddress());
			ps.setString(3, Customer.getMobile());
			ps.setInt(4, Customer.getId());
			rowUpdated = ps.executeUpdate() > 0;
		} catch (Exception e) {
			e.printStackTrace();
		}		
		return rowUpdated;
	}

	// TO-DO: Implement deleteCustomer() method to delete record in table Customer  
	public boolean deleteCustomer(Customer Customer) throws SQLException {
		Connection connection = DBConnect.getConnection();
		boolean rowDeleted = false;
		try {
			String deleteSQL = "DELETE FROM Customer WHERE ID = ?;";
			PreparedStatement ps = connection.prepareStatement(deleteSQL);
			ps.setInt(1, Customer.getId());
			rowDeleted = ps.executeUpdate() > 0;;
		} catch (Exception e) {
			e.printStackTrace();
		}
			
		return rowDeleted;
	}
}
