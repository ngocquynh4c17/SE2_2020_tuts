CREATE schema CLOTHES;

USE CLOTHES;

CREATE TABLE SHIRT (
ID INT NOT NULL AUTO_INCREMENT,
Style VARCHAR(50) NOT NULL,
Name VARCHAR(255) NOT NULL,
Price varchar(11) NOT NULL,
PRIMARY KEY(ID));              

INSERT INTO SHIRT (Style, Name, Price) VALUE ("Crop-top", "Ao crop-top vang quai beo", "100000"), 
													("T-shirt", "Ao phong tron in Tom&Jerry", "150000"),
                                                    ("Over-size", "So mi over-size soc xanh", "190000");

CREATE TABLE DRESS (
ID INT NOT NULL AUTO_INCREMENT,
Style VARCHAR(50) NOT NULL,
Name VARCHAR(255) NOT NULL,
Price varchar(11) NOT NULL,
PRIMARY KEY(ID));  

INSERT INTO DRESS (Style, Name, Price) VALUE ("Vay xuông", "Vay chiffon xanh", "250000"), 
													("Vay xoe", "Vay bong co beo hoa nhi", "200000"),
                                                    ("Chan vay", "Chan vay tennis", "190000");    
                                                    
CREATE TABLE Customer (
ID INT NOT NULL AUTO_INCREMENT,
NAME VARCHAR(30) NOT NULL,
ADDRESS VARCHAR(50) NOT NULL,
MOBILE VARCHAR(10) NOT NULL,
PRIMARY KEY(ID));
/* Insert data to this table */
INSERT INTO Customer (NAME, ADDRESS, MOBILE) VALUE ("Hoàng", "Hà Nội", "0912345678"), ("Minh", "Đà Nẵng", "0988888888"),
											   ("Phương", "HCM", "0986868686");